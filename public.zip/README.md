# Edward Somera React Portfolio

A responsive one-page React/Vite portfolio based on the supplied black and gold design.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Notes

- Replace the placeholder phone number in `src/App.jsx`.
- Add `public/Edward-Somera-CV.pdf` to enable the CV download button.
- Update the LinkedIn URL and project URLs as needed.
- The contact form currently uses FormSubmit. Replace it with your preferred backend or service if required.
