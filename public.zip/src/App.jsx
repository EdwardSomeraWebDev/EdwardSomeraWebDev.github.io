import {
  ArrowRight, CalendarDays, Code2, Download, ExternalLink,
  Mail, MapPin, Menu, Phone, Send, Star, UserRound, X
} from 'lucide-react';
import { useEffect, useState } from 'react';
import portrait from './assets/edward-portrait.jpg';

const skills = [
  { title: 'Front-end', items: [
    ['HTML5','H5','html'], ['CSS3','C3','css'], ['JavaScript','JS','js'], ['TypeScript','TS','ts'],
    ['React','⚛','react'], ['Vue.js','V','vue'], ['Next.js','N','next']
  ]},
  { title: 'Back-end', items: [
    ['Node.js','JS','node'], ['PHP','php','php'], ['REST API','⚙','rest'], ['MySQL','My','mysql']
  ]},
  { title: 'Tools & Others', items: [
    ['WordPress','W','wp'], ['Git','◆','git'], ['Docker','▰','docker'], ['Figma','F','figma'],
    ['VS Code','⌁','vscode'], ['Postman','◉','postman'], ['Linux','♟','linux']
  ]},
];

const projects = [
  { title:'HaulSaver', description:'Reverse marketplace platform that connects shippers with providers. Built with React, Node.js and Sharetribe Flex.', tags:['React','Node.js','MySQL'], className:'project-haulsaver', url:'https://haulsaver.com' },
  { title:'SativaBliss', description:'Multi-store eCommerce website for cannabis retail with store locator, product filters and TechPOS API integration.', tags:['WordPress','WooCommerce','PHP'], className:'project-sativa', url:'https://sativabliss.ca' },
  { title:'Toro Vape', description:'eCommerce website with subscription (Refill Club), custom checkout and product variations.', tags:['WordPress','WooCommerce','JavaScript'], className:'project-toro', url:'https://torovape.com' },
];

const experience = [
  { dates:'Nov 2019 – Jun 2025', role:'Applications Engineer / Developer 4', company:'Seven Seven Global Services Inc.', description:'Developed and maintained clients’ web applications using React, Vue, WordPress and REST APIs.' },
  { dates:'2016 – 2019', role:'Senior Web Developer', company:'Blueprint Solutions Group', description:'Built responsive websites and web apps for various industries.' },
  { dates:'2012 – 2016', role:'Web Developer', company:'Click4Corp', description:'Developed WordPress themes, custom plugins and client websites.' },
];

export default function App(){
  const [menuOpen,setMenuOpen]=useState(false);
  const [scrolled,setScrolled]=useState(false);
  useEffect(()=>{const fn=()=>setScrolled(window.scrollY>16); window.addEventListener('scroll',fn); return()=>window.removeEventListener('scroll',fn)},[]);
  const close=()=>setMenuOpen(false);
  return <div className="site-shell">
    <header className={`site-header ${scrolled?'scrolled':''}`}>
      <a className="brand" href="#home" onClick={close}>
        <span className="brand-mark">ES</span><span><strong>Edward Somera</strong><small>Web Developer</small></span>
      </a>
      <button className="menu-toggle" onClick={()=>setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen?<X/>:<Menu/>}</button>
      <nav className={menuOpen?'open':''}>
        {['About','Skills','Projects','Experience','Contact'].map(i=><a key={i} href={`#${i.toLowerCase()}`} onClick={close}>{i}</a>)}
        <a className="button button-outline nav-cta" href="/assets/Edward_Somera_CV.pdf" download>Download CV <Download size={15}/></a>
      </nav>
    </header>

    <main>
      <section className="hero section" id="home">
        <div className="hero-copy">
          <span className="eyebrow">Hi, I'm</span>
          <h1>Edward Somera</h1><h2>Web Developer</h2>
          <p>I build modern, responsive and performance-driven web applications with clean code and great user experiences.</p>
          <div className="hero-actions"><a className="button button-primary" href="#projects">View my work <ArrowRight size={17}/></a><a className="button button-outline" href="#contact">Contact me <Mail size={16}/></a></div>
          <div className="socials"><a href="https://github.com/EdwardSomeraWebDev" target="_blank" rel="noreferrer"><b>GH</b></a><a href="https://www.linkedin.com" target="_blank" rel="noreferrer"><b>IN</b></a><a className="cube" href="#skills">◇</a><a href="mailto:edwardsomerawebdev@gmail.com"><Mail/></a></div>
        </div>
        <div className="hero-visual">
          <div className="portrait-wrap"><img src={portrait} alt="Edward Somera"/></div>
          <div className="code-card"><span className="code-dots"><i/><i/><i/></span><pre>{`const developer = {\n  name: 'Edward Somera',\n  skills: ['JavaScript',\n    'React', 'Node.js',\n    'WordPress'],\n  passion: 'Building things\n    that make impact'\n};`}</pre></div>
          <Code2 className="hero-code-icon"/>
          <div className="dot-grid"/>
        </div>
      </section>

      <section className="section bordered" id="about"><div className="about-grid">
        <div><SectionTitle>About me</SectionTitle><p className="muted">Web developer with 12+ years of experience building websites and web applications. I specialize in front-end development using modern JavaScript frameworks and WordPress development. I enjoy turning ideas into scalable, high-performance solutions.</p><a href="#contact" className="mini-button">More about me <UserRound size={14}/></a></div>
        <div className="stats-grid"><Stat icon={<CalendarDays/>} value="12+" label={<>Years<br/>Experience</>}/><Stat icon={<Code2/>} value="50+" label={<>Projects<br/>Completed</>}/><Stat icon={<Star/>} value="100%" label={<>Client<br/>Satisfaction</>}/><Stat icon={<MapPin/>} value="Philippines" label={<>Based in<br/>Lucena City</>} compact/></div>
      </div></section>

      <section className="section bordered" id="skills"><SectionTitle>Skills & tools</SectionTitle><div className="skills-grid">
        {skills.map(group=><div className="skill-group" key={group.title}><h3>{group.title}</h3><div className="skill-list">{group.items.map(([name,mark,cls])=><div className="skill" key={name}><span className={`skill-icon ${cls}`}>{mark}</span><small>{name}</small></div>)}</div></div>)}
      </div></section>

      <section className="section bordered" id="projects"><div className="section-heading-row"><SectionTitle>Projects</SectionTitle><a className="text-link" href="https://edwardsomerawebdev.github.io" target="_blank" rel="noreferrer">View all projects <ArrowRight size={15}/></a></div><div className="projects-grid">
        {projects.map(p=><article className="project-card" key={p.title}><a className={`project-image ${p.className}`} href={p.url} target="_blank" rel="noreferrer"><span className="mock-site"><b>{p.title}</b><em>Modern digital experience</em><i>Explore project</i></span><ExternalLink size={16}/></a><div className="project-body"><h3>{p.title}</h3><p>{p.description}</p><div className="tags">{p.tags.map(t=><span key={t}>{t}</span>)}</div></div></article>)}
      </div></section>

      <section className="section bordered" id="experience"><SectionTitle>Experience</SectionTitle><div className="timeline-grid">{experience.map(e=><article className="timeline-item" key={e.role}><span className="timeline-dot"/><small>{e.dates}</small><h3>{e.role}</h3><strong>{e.company}</strong><p>{e.description}</p></article>)}</div></section>

      <section className="section contact-section bordered" id="contact"><div className="contact-copy"><SectionTitle>Let's work together!</SectionTitle><p>I'm currently open to new opportunities.</p><a href="mailto:edwardsomerawebdev@gmail.com"><Mail size={17}/> edwardsomerawebdev@gmail.com</a><a href="tel:+639171234567"><Phone size={17}/> +63 917 123 4567</a><span><MapPin size={17}/> Lucena City, Philippines</span></div><form className="contact-form" action="https://formsubmit.co/edwardsomerawebdev@gmail.com" method="POST"><div className="form-row"><input name="name" placeholder="Your Name" required/><input type="email" name="email" placeholder="Your Email" required/></div><textarea name="message" placeholder="Your Message" rows="4" required/><button className="button button-primary" type="submit">Send message <Send size={15}/></button></form></section>
    </main>
    <footer><span>© {new Date().getFullYear()} Edward Somera. All rights reserved.</span><a href="#home">Back to top ↑</a></footer>
  </div>
}
function SectionTitle({children}){return <h2 className="section-title">{children}</h2>}
function Stat({icon,value,label,compact=false}){return <div className="stat-card"><span className="stat-icon">{icon}</span><strong className={compact?'compact':''}>{value}</strong><small>{label}</small></div>}
